<p align="center"><a href="https://t.me/PyXen"><img src="https://telegra.ph/file/7a2e0a67e160deb60e48b.jpg" width="400"></a></p>
</p>
<h6 align="center">
  <b>• sᴛʀᴀɴɢᴇʀ ᴜsᴇʀ ʙᴏᴛ •</b>
</h6>

----

<h2> Heroku Deployment </h2>

> The easy way to host this bot, deploy to Heroku 
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/itzshukla/STRANGER-OPUSERBOT2.0)

## 🖇 Generating Pyrogram String Session

<p>
<a href="https://t.me/StringSesssionGeneratorRobot"><img src="https://img.shields.io/badge/TG%20String%20Gen%20Bot-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a>

### Contact :
<a href="https://t.me/SHIVANSH39"><img title="Telegram" src="https://img.shields.io/badge/Telegram-%23000000.svg?&style=for-the-badge&logo=telegram&logoColor=61DAFB"></a>
