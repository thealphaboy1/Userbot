# Powered By // @SHIVANSH474 //

__NAME__ = "Sʜᴜᴋʟᴀ"
__MENU__ = """
 **@SHIVANSH474**
"""
