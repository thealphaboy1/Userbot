# Powered By // @SHIVANSH474 //

__NAME__ = "Vᴄ Bᴏᴛ"
__MENU__ = """
**An Advanced High Quality Music
And Video Player System.**

`.join` - Join Stream Chat VC.
`.lve` - Leave From Stream VC.
`.ply` - Play Your Audio Song.
`.vply` - Play Your Video Song.
`.pse` - Pause Running Stream.
`.rsm` - Resume Paused Stream.
`.skp` - Skip To Next Song.
`.stp` - Stop Streaming On Vc.
"""

